﻿using System;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.IO.Ports;
using System.Threading;
using System.Windows.Threading;
using System.Diagnostics;

using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows.Controls.Primitives;

namespace isilproto
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 

    public partial class MainWindow1
    {

        Boolean startupRest = false;
        string[] pollint = new string[] { "", "A", "B", "C", "D", "E" };


        public System.Windows.Threading.DispatcherTimer dispatcherTimer;


        public string rest = "-1,0,0,0,0";
        public string getAllDeviceStatus = "3,0,0,0,0";
      int[,] deviceStatus = new int[1, 6];

     //   int[,] deviceStatus = new int[,] { { 2, 1, 0, 3, 0, 0 }, { 3, 1, 0, 0, 0, 1 }, { 5, 2, 0, 0, 1, 2 }, { 7, 0, 0, 0, 0, 0 } };
        #region variables
        //Richtextbox
        FlowDocument mcFlowDoc = new FlowDocument();
        Paragraph para = new Paragraph();
        //Serial 
        SerialPort serial = new SerialPort();
        SerialPort serial1 = new SerialPort();
        string recieved_data = "";
        #endregion
        public MainWindow1()
        {
            InitializeComponent();
            btnConnect.Content = "Connect";



            string[] ports = SerialPort.GetPortNames();

            Console.WriteLine("The following serial ports were found:");

            // Display each port name to the console. 
            foreach (string port in ports)
            {
                comboPort.Items.Add(port);
                comboPortReceive.Items.Add(port);
                System.Diagnostics.Debug.WriteLine(port);
            }
            //  populateButtons(60, 60, 10,     10, 10, 10);

            for (int i = 1; i < 10; ++i)
            {
                ToggleButton btnUser = new ToggleButton();
                ToggleButton btnUserPrivate = new ToggleButton();
                btnUser.IsChecked = true;
                btnUserPrivate.IsChecked = true;

              

                btnUserPrivate.IsEnabled = false;
                btnUser.IsEnabled = false;

                Label lblUser = new Label();
                Label lblUserPoll = new Label();
                Label lblUserFff = new Label();
                btnUser.Content = i.ToString();
                btnUser.Name = "Ubt_" + i;
                this.RegisterName("Ubt_" + i, btnUser);
                btnUserPrivate.Name = "UbtP_" + i;
                this.RegisterName("UbtP_" + i, btnUserPrivate);
                lblUser.Name = "lblUser_" + i;
                lblUserPoll.Name = "lblUserPoll_" + i;
                this.RegisterName("lblUserPoll_" + i, lblUserPoll);
                this.RegisterName("lblUser_" + i, lblUser);
                // lblUserPoll.Content = "A" +i;
                lblUserPoll.Margin = new Thickness(-50, -110, 0, 0);
                lblUserPoll.Height = 30;
                lblUser.Height = 30;
                lblUserPoll.Background = new SolidColorBrush(Colors.Pink);
                //lblUser.Content = "01" +i;

                lblUser.Margin = new Thickness(-50, 130, 0, 0);
                lblUser.Background = new SolidColorBrush(Colors.Peru);

                lblUserFff.Name = "lblUserFff_" + i;
                this.RegisterName("lblUserFff_" + i, lblUserFff);
                //  lblUserFff.Content = "0" + i;


                lblUserFff.Height = 30;

                lblUserFff.Background = new SolidColorBrush(Colors.PapayaWhip);

                lblUserFff.Margin = new Thickness(-50, 190, 0, 0);


                btnUser.Height = 60;
                btnUser.Width = 60;
                btnUserPrivate.Height = 20;
                btnUserPrivate.Width = 60;
              

                btnUser.Click += new RoutedEventHandler(btnClickOnetomany);
                btnUserPrivate.Click += new RoutedEventHandler(btnClickPrivate);

                //button.mar
                btnUser.SetValue(Grid.RowProperty, 1);
                btnUser.SetValue(Grid.ColumnProperty, 0);
                btnUserPrivate.SetValue(Grid.RowProperty, 1);
                btnUserPrivate.SetValue(Grid.ColumnProperty, 0);

                btnUserPrivate.Margin = new Thickness(-60, 60, 0, 0);
                sp.Children.Add(btnUser);
                sp.Children.Add(btnUserPrivate);
                sp.Children.Add(lblUserPoll);
                sp.Children.Add(lblUser);
                sp.Children.Add(lblUserFff);

            }
          //  MessageBox.Show(Properties.Settings.Default.pd);
       

            connetPort();

 dispatcherTimer = new System.Windows.Threading.DispatcherTimer();
            dispatcherTimer.Tick += new EventHandler(AllStudentStatus);
         dispatcherTimer.Interval = new TimeSpan(10000) ;
    
    
        //    reset();


        }

        private void AllStudentStatus(object sender, EventArgs e)
        {
            AllStudentStatus();
        }

        public void btnClickPrivate(object sender, RoutedEventArgs e)
        {

            ToggleButton clicked = (ToggleButton)sender;
            var data = Regex.Match(clicked.Name, @"\d+").Value;
            // MessageBox.Show("p"+data);
            //   SerialCmdSend("2,"+data+",2,1,2");
         

            if (clicked.IsChecked == false)
            {
                SerialCmdSend("2," + data + ",2,1,2");
            }
            else
            {

                SerialCmdSend("2," + data + ",0,0,1");
            }


            AllStudentStatus();
        }

        private void btnClickOnetomany(object sender, RoutedEventArgs e)
        {
           
            ToggleButton clicked = (ToggleButton)sender;
            var data = Regex.Match(clicked.Name, @"\d+").Value;
            //  MessageBox.Show(data);
         
            if (clicked.IsChecked == false) { 
            SerialCmdSend("2," + data + ",2,1,1");
            }
            else
            {

                SerialCmdSend("2," + data + ",0,0,1");
            }
           

            AllStudentStatus();
        }

        public async void reset()
        {
          
           // Thread.Sleep(1000);
      //    SerialCmdSend("-1,0,0,0,0");
          //  Thread.Sleep(1000);
        }

        private void reset_all(object sender, RoutedEventArgs e)
        {
            //  var controller = await this.ShowProgressAsync("Please wait...", "Progress message");

            reset();
            //  MessageBox.("Reset >>>>>>>>>!!!");

        //    MessageBox.Show("Reset Done");

            // TextSerialData.Text = "";
            AllStudentStatus();
        }

        public async void updateBtnStatus()
        {

            // D. Get both bounds.
            int bound0 = deviceStatus.GetUpperBound(0);
            int bound1 = deviceStatus.GetUpperBound(1);
            for (int i = 0; i <= bound0; i++)
            {

           //  MessageBox.Show(i.ToString());



                //   btnUserPrivate.Background = new SolidColorBrush(Colors.Bisque);
                Label fff = (Label)this.FindName("lblUserFff_" + deviceStatus[i, 0]);
                Label poll = (Label)this.FindName("lblUserPoll_" + deviceStatus[i, 0]);
                Label call = (Label)this.FindName("lblUser_" + deviceStatus[i, 0]);
                ToggleButton b = (ToggleButton)this.FindName("Ubt_" + deviceStatus[i, 0]);
                ToggleButton b1 = (ToggleButton)this.FindName("UbtP_" + deviceStatus[i, 0]);

                if (fff is Label)
                {

                    fff.Content = deviceStatus[i, 2];

                }

                if (poll is Label)
                {


                    try
                    {
                        poll.Content = pollint[deviceStatus[i, 3]];
                    }
                    catch
                    {

                    }
                }

                if (call is Label)
                {
                    if (deviceStatus[i, 1] == 1 && deviceStatus[i, 4] == 0 && deviceStatus[i, 5] != 2)
                    {
                        call.Content = "Call!!";

                    }
                    else if (deviceStatus[i, 1] == 2 && deviceStatus[i, 5] == 1)
                    {
                        call.Content = "Grab!!";
                    }

                    else if (deviceStatus[i, 1] == 2 && deviceStatus[i, 5] == 2)
                    {
                        call.Content = "PT Call!";
                    }

                    else
                    {
                        call.Content = "";
                    }




                }

                if (b is ToggleButton)
                {
                  
                    b.IsEnabled = true;
                    b.Background = new SolidColorBrush(Colors.Blue);
                  


                    if (deviceStatus[i, 1] == 2 && deviceStatus[i, 5] == 2 )
                    {
                     b.Background = new SolidColorBrush(Colors.Yellow);
                     b.IsChecked = false;

                    }
                 
                    else
                    {


                        b.IsChecked = true;
                       
                    }

                }

                if (b1 is ToggleButton)
                {
                    b1.IsEnabled = true;
                    b1.Background = new SolidColorBrush(Colors.Red);


                    if (deviceStatus[i, 1] == 2 && deviceStatus[i, 5] == 1 )
                    {
                      b1.Background = new SolidColorBrush(Colors.Green);
                      b1.IsChecked = false;
                    }
                    else
                    {


                        b1.IsChecked = true;
                       
                    }
                }
                //  for (int x = 0; x <= bound1; x++)
                //  {

                //    int s1 = deviceStatus[i, x];
                //      Console.WriteLine(s1);
                //   }
                //  Console.WriteLine();
            }

        }


        private void IntbuttonClick(object sender, RoutedEventArgs e)
        {
            throw new NotImplementedException();
        }

        private void UserButtonClickedEvent(object sender, RoutedEventArgs e)
        {
            throw new NotImplementedException();
        }
        private void Connect_Comms(object sender, RoutedEventArgs e)
        {
               
            connetPort();
        }

        private void connetPort()
        {
            if (btnConnect.Content == "Connect")
            {



                try
                {
                
                serial.PortName = ((comboPort).SelectedItem).ToString();

                serial.BaudRate = 9600;
                serial.Handshake = System.IO.Ports.Handshake.RequestToSendXOnXOff;
                serial.Parity = Parity.None;
                serial.DataBits = 8;
                serial.StopBits = StopBits.Two;
                serial.ReadTimeout = 100;
                serial.WriteTimeout =100;
              

                    serial.Open();

                    serial1.PortName = ((comboPortReceive).SelectedItem).ToString();

                    serial1.BaudRate = 9600;
                    serial1.Handshake = System.IO.Ports.Handshake.RequestToSendXOnXOff;
                    serial1.Parity = Parity.None;
                    serial1.DataBits = 8;
                    serial1.StopBits = StopBits.Two;
                    serial1.ReadTimeout = 100;
                    serial1.WriteTimeout = 100;


                    serial1.Open();
                    btnConnect.Content = "Disconnect";
             //       Properties.Settings.Default.pd = ((comboPort).SelectedItem).ToString();
                    Properties.Settings.Default.Save();
                    dispatcherTimer.Start();
                   
                }
                catch (Exception e1)
                {
                    MessageBox.Show("Please Check the Serial Port!!!");
                }





                //  SerialCmdSend(rest);

                //Sets button State and Creates function call on data recieved

                serial.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(Recieve);
                //    Thread.Sleep(500);



            }
            else
            {
                dispatcherTimer.Stop();
                try // just in case serial port is not open could also be acheved using if(serial.IsOpen)
                {

                    serial1.Close();
                    serial.Close();
                    startupRest = false;
                    Thread.Sleep(500);
                    btnConnect.Content = "Connect";
                    Thread.Sleep(500);
                }
                catch
                {
                }
            }
        }

        public async void AllStudentStatus()
        {
            //  System.Diagnostics.Debug.WriteLine(recieved_data);
            SerialCmdSend1(getAllDeviceStatus);
              //  MessageBox.Show(recieved_data);
          //  Array.Clear(recieved_data, 0, recieved_data.Length);
            int z = 0;
            int y = 0;
            while ((z = recieved_data.IndexOf("GD,", z)) != -1)
            {

                // C.
                // Print out the substring.
                //   System.Diagnostics.Debug.WriteLine(recieved_data.Substring(z + 3,11));
                try
                {
                    string tempsubstring = recieved_data.Substring(z + 3, 13);

                    string[] pieces = tempsubstring.Split(new string[] { "," }, StringSplitOptions.None);

                    deviceStatus = (int[,])ResizeArray(deviceStatus, new int[] { y + 1, 6 });
                    for (int i = 0; i < pieces.Length; i++)
                    {
                        deviceStatus[y, i] = Int32.Parse(pieces[i]);

                    }
                }
                catch (Exception e1)
                {
                    // error handling code
                }
                // D.
                // Increment the index.
                z++;
                y++;
            }





            //  myArr2.SetValue("one-three", 1, 3);

            // ThreadTest tt = new ThreadTest();   // Create a common instance

            updateBtnStatus();

        }

        private static Array ResizeArray(Array arr, int[] newSizes)
        {
            if (newSizes.Length != arr.Rank)
                throw new ArgumentException("arr must have the same number of dimensions " +
                                            "as there are elements in newSizes", "newSizes");

            var temp = Array.CreateInstance(arr.GetType().GetElementType(), newSizes);
            int length = arr.Length <= temp.Length ? arr.Length : temp.Length;
            Array.ConstrainedCopy(arr, 0, temp, 0, length);
            return temp;
        }

        #region Recieving

        private delegate void UpdateUiTextDelegate(string text);
        private  void Recieve(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
          

            //display the data to the user
            try
            {
                recieved_data = serial.ReadLine();
               // AllStudentStatus();

              //  Thread.Sleep(100000000);
                if (startupRest == false)
                {
                    reset();
                    startupRest = true;

                }

            }
            catch (Exception e1)
            {
                // error handling code
            }
            // System.Diagnostics.Debug.WriteLine(recieved_data);


            Dispatcher.Invoke(DispatcherPriority.Send, new UpdateUiTextDelegate(WriteData), recieved_data);
         //  AllStudentStatus();
  





        }
        private async void WriteData(string text)
        {


            // Assign the value of the recieved_data to the RichTextBox.
          //  para.Inlines.Add(text);
          //  mcFlowDoc.Blocks.Add(para);
          //  textLog.Document = mcFlowDoc;
            /*         try
                     {
                         // statements causing exception


                         int rowLength = deviceStatus.GetLength(0);
                         int colLength = deviceStatus.GetLength(1);
                         Stopwatch stopwatch = new Stopwatch();
                         stopwatch.Start();
                         // put your code here
                
                         for (int i = 0; i < rowLength; i++)
                         {
                             for (int x = 0; x < colLength; x++)
                             {
                                 int s1 = deviceStatus[i, x];
                                 para.Inlines.Add("row=" + i + "col=" + x + "value=" + s1.ToString());
                                 mcFlowDoc.Blocks.Add(para);
                                 textLog.Document = mcFlowDoc;
                             }

                         }

                         stopwatch.Stop();
                         //timeinsecond variable will be set to time seconds for your execution.
                         System.Diagnostics.Debug.WriteLine(stopwatch.Elapsed); 
                     }
                     catch (NullReferenceException e1)
                     {
                         // error handling code
                     }*/
        }

        #endregion


        #region Sending

        private async void Send_Data(object sender, RoutedEventArgs e)
        {
            SerialCmdSend(TextSerialData.Text);
            // TextSerialData.Text = "";

        }


        public async void SerialCmdSend(string data)
        {


            if (serial1.IsOpen)
            {
                try
                {


                    // Send the binary data out the port
                    byte[] hexstring = Encoding.ASCII.GetBytes(data);
                    //There is a intermitant problem that I came across
                    //If I write more than one byte in succesion without a 
                    //delay the PIC i'm communicating with will Crash
                    //I expect this id due to PC timing issues ad they are
                    //not directley connected to the COM port the solution
                    //Is a ver small 1 millisecound delay between chracters
                    foreach (byte hexval in hexstring)
                    {
                        byte[] _hexval = new byte[] { hexval }; // need to convert byte to byte[] to write
                      serial1.Write(_hexval, 0, 1);
                    //    Thread.Sleep(1);
                    }
                    serial1.Write("\n");
                }
                catch (Exception ex)
                {
                    TextSerialData.Text = "Failed to SEND";
                    para.Inlines.Add("Failed to SEND" + data + "\n" + ex + "\n");
                    mcFlowDoc.Blocks.Add(para);
                    textLog.Document = mcFlowDoc;
                }
            }
            else
            {
            }
        }

        public async void SerialCmdSend1(string data)
        {


            if (serial.IsOpen)
            {
                try
                {


                    // Send the binary data out the port
                    byte[] hexstring = Encoding.ASCII.GetBytes(data);
                    //There is a intermitant problem that I came across
                    //If I write more than one byte in succesion without a 
                    //delay the PIC i'm communicating with will Crash
                    //I expect this id due to PC timing issues ad they are
                    //not directley connected to the COM port the solution
                    //Is a ver small 1 millisecound delay between chracters
                    foreach (byte hexval in hexstring)
                    {
                        byte[] _hexval = new byte[] { hexval }; // need to convert byte to byte[] to write
                        serial.Write(_hexval, 0, 1);
                      //  Thread.Sleep(1);
                    }
                    serial.Write("\n");
                }
                catch (Exception ex)
                {
                    TextSerialData.Text = "Failed to SEND";
                    para.Inlines.Add("Failed to SEND" + data + "\n" + ex + "\n");
                    mcFlowDoc.Blocks.Add(para);
                    textLog.Document = mcFlowDoc;
                }
            }
            else
            {
            }
        }

        #endregion



        private void btnAllowCall_Click(object sender, RoutedEventArgs e)
        {

            Button clicked = (Button)sender;
            if (clicked.Content == "Allow Call")
            {
              //  SerialCmdSend("");

            }


        }

        private void btn_pc_Click(object sender, RoutedEventArgs e)
        {
           
   
        }

        private void pa_btn_Click(object sender, RoutedEventArgs e)
        {

         

        }

        private void btnPA_Checked(object sender, RoutedEventArgs e)
        {
            SerialCmdSend("4,1,-1,-1,-1");
        }
        private void btnPA_UnChecked(object sender, RoutedEventArgs e)
        {
            SerialCmdSend("4,0,-1,-1,-1");
        }

        private void btnPA_Copy_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void btnPC_Checked(object sender, RoutedEventArgs e)
        {
         SerialCmdSend("4,-1,1,-1,-1");
        }
        private void btnPC_UnChecked(object sender, RoutedEventArgs e)
        {
            SerialCmdSend("4,-1,0,-1,-1");
        }

        private void aux_btn_UnChecked(object sender, RoutedEventArgs e)
        {
            SerialCmdSend("4,-1,-1,0,-1");
        }
        private void aux_btn_Checked(object sender, RoutedEventArgs e)
        {
            SerialCmdSend("4,-1,-1,1,-1");
        }

        private void btnHigh_Click(object sender, RoutedEventArgs e)
        {
            SerialCmdSend("5,-1,-1,1,-1");
        }

        private void btnLow_Click(object sender, RoutedEventArgs e)
        {
            SerialCmdSend("5,-1,-1,0,-1");
        }
    }
}
